//
//  TipComponents.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct FeaturedTipCard: View {
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("💡 Tip del Día")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("Planifica tus comidas")
                .font(.headline)
            
            Text("Dedica 30 minutos cada domingo para planificar tus comidas de la semana. Esto te ayudará a mantener una dieta balanceada y ahorrar tiempo.")
                .foregroundColor(.gray)
            
            HStack {
                Image(systemName: "clock.fill")
                    .foregroundColor(mainYellow)
                Text("Hace 2 horas")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

struct TipCard: View {
    let tip: Tip
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: tip.icon)
                    .foregroundColor(tip.category.color)
                    .font(.title2)
                
                Text(tip.title)
                    .font(.headline)
            }
            
            Text(tip.description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .lineLimit(3)
            
            HStack {
                Spacer()
                Image(systemName: "chevron.right.circle.fill")
                    .foregroundColor(tip.category.color)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

struct CategorySection: View {
    let category: TipCategory
    let tips: [Tip]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: category.icon)
                    .foregroundColor(category.color)
                Text(category.rawValue)
                    .font(.title2)
                    .fontWeight(.bold)
            }
            .padding(.horizontal)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(tips) { tip in
                        TipCard(tip: tip)
                            .frame(width: 280)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}
