import SwiftUI

struct CustomTabBar: View {
    @Binding var selectedTab: Tab
    @Binding var showingAddMealMenu: Bool
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    var body: some View {
        ZStack {
            // Main HStack with regular tabs
            HStack(spacing: 0) {
                ForEach([Tab.stats, Tab.recommendations, Tab.home, Tab.history, Tab.homeAlt], id: \.self) { tab in
                    VStack(spacing: 4) {
                        if tab == .home {
                            // Invisible placeholder for center button
                            Color.clear
                                .frame(width: 32, height: 32)
                        } else {
                            Button {
                                selectedTab = tab
                            } label: {
                                VStack(spacing: 4) {
                                    Image(systemName: tab.iconName)
                                        .font(.system(size: 20))
                                    Text(tab.rawValue)
                                        .font(.system(size: 12))
                                }
                                .foregroundColor(selectedTab == tab ? mainYellow : .gray)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 8)
            .padding(.top, 14)
            .padding(.bottom, 24)
            .background(
                Color.white
                    .shadow(color: Color.black.opacity(0.15), radius: 15, x: 0, y: -3)
            )
            
            // Floating add meal button
            Button {
                showingAddMealMenu = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 56, height: 56)
                    .background(mainYellow)
                    .clipShape(Circle())
                    .shadow(color: mainYellow.opacity(0.4), radius: 10, x: 0, y: 5)
            }
            .offset(y: -20)
        }
    }
}
