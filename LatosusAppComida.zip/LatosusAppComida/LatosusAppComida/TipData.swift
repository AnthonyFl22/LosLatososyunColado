//
//  TipData.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import Foundation

class TipData {
    static let tips = [
        // Breakfast tips
        Tip(title: "Desayuno Balanceado",
            description: "Incluye proteínas, carbohidratos y grasas saludables. Un ejemplo perfecto: avena con plátano, nueces y yogurt.",
            icon: "sunrise.fill",
            category: .breakfast),
        Tip(title: "Frutas en la Mañana",
            description: "Las frutas son mejor absorbidas en la mañana. Aprovecha para incluir frutos rojos o cítricos.",
            icon: "apple.logo",
            category: .breakfast),
        
        // Hydration tips
        Tip(title: "Agua con Limón",
            description: "Comienza tu día con un vaso de agua con limón para activar tu metabolismo y depurar tu organismo.",
            icon: "drop.fill",
            category: .hydration),
        Tip(title: "Recordatorio de Agua",
            description: "Bebe un vaso de agua entre cada comida. Establece recordatorios si es necesario.",
            icon: "bell.fill",
            category: .hydration),
        
        // Snacks tips
        Tip(title: "Snacks Saludables",
            description: "Mantén frutos secos, frutas o verduras cortadas para evitar antojos de comida chatarra.",
            icon: "carrot.fill",
            category: .snacks),
        Tip(title: "Control de Porciones",
            description: "Usa contenedores pequeños para tus snacks y evita comer directamente del paquete.",
            icon: "square.stack.fill",
            category: .snacks),
        
        // Nutrition tips
        Tip(title: "Proteína en cada Comida",
            description: "Incluye una fuente de proteína en cada comida para mantener tu saciedad por más tiempo.",
            icon: "fork.knife",
            category: .nutrition),
        Tip(title: "Vegetales de Colores",
            description: "Mientras más colorido tu plato, más variedad de nutrientes. Come el arcoíris.",
            icon: "leaf.fill",
            category: .nutrition)
    ]
}
