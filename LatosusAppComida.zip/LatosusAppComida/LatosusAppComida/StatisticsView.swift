//
//  StatisticsView.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct DayStatus {
    let date: Date
    let status: DietStatus
    let calories: Int
}

enum DietStatus {
    case excellent
    case good
    case normal
    case poor
    
    var color: Color {
        switch self {
        case .excellent: return .green
        case .good: return .mint
        case .normal: return .yellow
        case .poor: return .red
        }
    }
}

struct StatisticsView: View {
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    // Hardcoded data for the calendar
    let monthData: [DayStatus] = {
        let calendar = Calendar.current
        let today = Date()
        var days: [DayStatus] = []
        
        for dayOffset in 0..<30 {
            if let date = calendar.date(byAdding: .day, value: -dayOffset, to: today) {
                let status: DietStatus
                let calories: Int
                
                // Create some pattern in the data
                switch dayOffset % 4 {
                case 0: status = .excellent; calories = 2100
                case 1: status = .good; calories = 2300
                case 2: status = .normal; calories = 2500
                case 3: status = .poor; calories = 2800
                default: status = .normal; calories = 2400
                }
                
                days.append(DayStatus(date: date, status: status, calories: calories))
            }
        }
        return days
    }()
    
    var averageCalories: Int {
        monthData.reduce(0) { $0 + $1.calories } / monthData.count
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    // Calendar View
                    CalendarView(monthData: monthData)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(color: Color.black.opacity(0.1), radius: 5)
                    
                    // Stats Cards
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 15) {
                        StatCard(
                            title: "Promedio Calorías",
                            value: "\(averageCalories)",
                            unit: "cal",
                            icon: "flame.fill",
                            color: .orange
                        )
                        
                        StatCard(
                            title: "Días Saludables",
                            value: "\(monthData.filter { $0.status == .excellent || $0.status == .good }.count)",
                            unit: "días",
                            icon: "leaf.fill",
                            color: .green
                        )
                        
                        StatCard(
                            title: "Racha Actual",
                            value: "7",
                            unit: "días",
                            icon: "bolt.fill",
                            color: mainYellow
                        )
                        
                        StatCard(
                            title: "Meta Cumplida",
                            value: "85",
                            unit: "%",
                            icon: "target",
                            color: .blue
                        )
                    }
                    .padding(.horizontal)
                    
                    // Calories Trend Chart
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Tendencia de Calorías")
                            .font(.headline)
                            .padding(.horizontal)
                        
                        CaloriesChart(data: monthData)
                            .frame(height: 200)
                            .padding()
                    }
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(color: Color.black.opacity(0.1), radius: 5)
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .background(mainYellow.opacity(0.1))
            .navigationTitle("Estadísticas")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct CalendarView: View {
    let monthData: [DayStatus]
    let columns = Array(repeating: GridItem(.flexible()), count: 7)
    let weekDays = ["D", "L", "M", "M", "J", "V", "S"]
    
    var body: some View {
        VStack(spacing: 10) {
            // Week days header
            LazyVGrid(columns: columns) {
                ForEach(weekDays, id: \.self) { day in
                    Text(day)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            
            // Calendar days
            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(0..<35, id: \.self) { index in
                    if index < monthData.count {
                        let dayStatus = monthData[index]
                        Circle()
                            .fill(dayStatus.status.color)
                            .frame(width: 30, height: 30)
                            .overlay(
                                Text("\(Calendar.current.component(.day, from: dayStatus.date))")
                                    .font(.caption2)
                                    .foregroundColor(.white)
                            )
                    } else {
                        Circle()
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 30, height: 30)
                    }
                }
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let unit: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(color)
            
            Text(value)
                .font(.system(size: 24, weight: .bold))
            
            Text(unit)
                .font(.caption)
                .foregroundColor(.gray)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

struct CaloriesChart: View {
    let data: [DayStatus]
    
    var body: some View {
        GeometryReader { geometry in
            let maxCalories = data.map { $0.calories }.max() ?? 3000
            let minCalories = data.map { $0.calories }.min() ?? 0
            let range = maxCalories - minCalories
            
            Path { path in
                for (index, dayStatus) in data.enumerated() {
                    let x = geometry.size.width * CGFloat(index) / CGFloat(data.count - 1)
                    let y = geometry.size.height * (1 - CGFloat(dayStatus.calories - minCalories) / CGFloat(range))
                    
                    if index == 0 {
                        path.move(to: CGPoint(x: x, y: y))
                    } else {
                        path.addLine(to: CGPoint(x: x, y: y))
                    }
                }
            }
            .stroke(LinearGradient(
                gradient: Gradient(colors: [.orange, .green]),
                startPoint: .leading,
                endPoint: .trailing
            ), lineWidth: 2)
            
            // Data points
            ForEach(0..<data.count, id: \.self) { index in
                let dayStatus = data[index]
                let x = geometry.size.width * CGFloat(index) / CGFloat(data.count - 1)
                let y = geometry.size.height * (1 - CGFloat(dayStatus.calories - minCalories) / CGFloat(range))
                
                Circle()
                    .fill(dayStatus.status.color)
                    .frame(width: 8, height: 8)
                    .position(x: x, y: y)
            }
        }
    }
}

#Preview {
    StatisticsView()
}
