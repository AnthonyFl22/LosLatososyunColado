//
//  SignupModels.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import Foundation

enum Gender: String, CaseIterable {
    case male = "Masculino"
    case female = "Femenino"
}

enum Goal: String, CaseIterable {
    case lose = "Bajar de peso"
    case maintain = "Mantener peso"
    case gain = "Subir de peso"
    
    var calorieModifier: Double {
        switch self {
        case .lose: return 0.8 // 20% deficit
        case .maintain: return 1.0
        case .gain: return 1.2 // 20% surplus
        }
    }
    
    var icon: String {
        switch self {
        case .lose: return "arrow.down.circle.fill"
        case .maintain: return "equal.circle.fill"
        case .gain: return "arrow.up.circle.fill"
        }
    }
}

struct UserFormData {
    var name: String = ""
    var age: String = ""
    var weight: String = ""
    var height: String = ""
    var gender: Gender = .female
    var goal: Goal = .maintain
    
    var isStepOneValid: Bool {
        !name.isEmpty && !age.isEmpty
    }
    
    var isStepTwoValid: Bool {
        !weight.isEmpty && !height.isEmpty
    }
    
    var calculatedIMC: Double? {
        guard let weight = Double(weight),
              let height = Double(height) else { return nil }
        let heightInMeters = height / 100
        return weight / (heightInMeters * heightInMeters)
    }
    
    var imcCategory: String {
        guard let imc = calculatedIMC else { return "---" }
        switch imc {
        case ..<18.5: return "Bajo peso"
        case 18.5..<24.9: return "Peso normal"
        case 25..<29.9: return "Sobrepeso"
        default: return "Obesidad"
        }
    }
    
    var dailyCalories: Int? {
        guard let weight = Double(weight),
              let height = Double(height),
              let age = Double(age) else { return nil }
        
        // Harris-Benedict Formula
        let bmr: Double
        if gender == .male {
            bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
        } else {
            bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
        }
        
        // Adjust for activity level (assuming moderate activity)
        let tdee = bmr * 1.375
        
        // Adjust based on goal
        return Int(tdee * goal.calorieModifier)
    }
}
