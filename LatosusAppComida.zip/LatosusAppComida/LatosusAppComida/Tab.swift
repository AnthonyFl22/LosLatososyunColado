//
//  Tab.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

enum Tab: String {
    case stats = "Estadísticas"
    case recommendations = "Tips"
    case home = "Home"
    case history = "Historial"
    case homeAlt = "Inicio"
    
    var iconName: String {
        switch self {
        case .stats:
            return "chart.bar.fill"
        case .recommendations:
            return "star.fill"
        case .home:
            return "house.fill"
        case .history:
            return "clock.fill"
        case .homeAlt:
            return "house.fill"
        }
    }
}
