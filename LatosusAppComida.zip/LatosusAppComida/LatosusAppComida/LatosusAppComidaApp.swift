//
//  LatosusAppComidaApp.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

@main
struct LatosusAppComidaApp: App {
    var body: some Scene {
        WindowGroup {
            SignupView()
        }
    }
}
