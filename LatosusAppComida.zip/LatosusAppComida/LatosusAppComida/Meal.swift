//
//  Meal.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import Foundation

struct Meal: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let caloriesPerPortion: Int
    let portions: Int
    let totalCalories: Int
    let dateAdded: Date
}
