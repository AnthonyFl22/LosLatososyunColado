import SwiftUI

struct SignupView: View {
    @State private var currentStep = 1
    @State private var formData = UserFormData()
    @State private var isShowingMain = false
    @State private var showError = false
    @State private var errorMessage = ""
    
    @StateObject private var userSettings = UserSettings()
    
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    private func saveData() {
        userSettings.name = formData.name
        userSettings.dailyGoal = formData.dailyCalories ?? 2000
        
        isShowingMain = true
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                mainYellow.opacity(0.1).ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 25) {
                        StepIndicator(currentStep: currentStep, totalSteps: 3, mainYellow: mainYellow)
                        
                        Text(stepTitle)
                            .font(.system(size: 35, weight: .bold))
                            .foregroundColor(.black)
                        
                        // Step Content
                        Group {
                            switch currentStep {
                            case 1:
                                stepOne
                            case 2:
                                stepTwo
                            case 3:
                                stepThree
                            default:
                                EmptyView()
                            }
                        }
                        .padding(.horizontal)
                        
                        Spacer(minLength: 30)
                        
                        NavigationButtons(
                            canProceed: canProceedToNextStep,
                            currentStep: currentStep,
                            onBack: { withAnimation { currentStep -= 1 } },
                            onNext: {
                                withAnimation {
                                    if currentStep == 3 {
                                        saveData()
                                    } else {
                                        currentStep += 1
                                    }
                                }
                            },
                            mainYellow: mainYellow
                        )
                    }
                    .padding(.vertical, 30)
                }
            }
            .navigationBarHidden(true)
        }
        .alert("Error", isPresented: $showError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
        .fullScreenCover(isPresented: $isShowingMain) {
            MainView()
                .environmentObject(userSettings)
        }
        .environmentObject(userSettings)
    }
    
    private var stepTitle: String {
        switch currentStep {
        case 1: return "Bienvenido a NutriApp"
        case 2: return "Medidas corporales"
        case 3: return "Objetivo"
        default: return ""
        }
    }
    
    private var canProceedToNextStep: Bool {
        switch currentStep {
        case 1: return formData.isStepOneValid
        case 2: return formData.isStepTwoValid
        case 3: return true
        default: return false
        }
    }
    
    private var stepOne: some View {
        VStack(spacing: 20) {
            CustomTextField(text: $formData.name, placeholder: "Nombre", imageName: "person.fill")
            
            CustomTextField(text: $formData.age, placeholder: "Edad", imageName: "calendar")
                .keyboardType(.numberPad)
            
            VStack(alignment: .leading, spacing: 10) {
                Text("Sexo")
                    .foregroundColor(.gray)
                    .padding(.leading)
                
                Picker("Gender", selection: $formData.gender) {
                    ForEach(Gender.allCases, id: \.self) { gender in
                        Text(gender.rawValue).tag(gender)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
    }
    
    private var stepTwo: some View {
        VStack(spacing: 20) {
            CustomTextField(text: $formData.weight, placeholder: "Peso (kg)", imageName: "scalemass.fill")
                .keyboardType(.decimalPad)
            
            CustomTextField(text: $formData.height, placeholder: "Altura (cm)", imageName: "ruler.fill")
                .keyboardType(.decimalPad)
            
            if let imc = formData.calculatedIMC {
                VStack(spacing: 10) {
                    Text("Tu IMC")
                        .font(.headline)
                        .foregroundColor(.gray)
                    
                    Text(String(format: "%.1f", imc))
                        .font(.system(size: 40, weight: .bold))
                    
                    Text(formData.imcCategory)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
            }
        }
    }
    
    private var stepThree: some View {
        VStack(spacing: 25) {
            // Goal selection
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                ForEach(Goal.allCases, id: \.self) { goal in
                    GoalCard(
                        goal: goal,
                        isSelected: formData.goal == goal,
                        mainYellow: mainYellow
                    )
                    .onTapGesture {
                        formData.goal = goal
                    }
                }
            }
            
            // Summary card
            if let calories = formData.dailyCalories {
                VStack(spacing: 20) {
                    Text("Tu plan personalizado")
                        .font(.headline)
                        .foregroundColor(.gray)
                    
                    VStack(spacing: 5) {
                        Text("\(calories)")
                            .font(.system(size: 40, weight: .bold))
                        Text("calorías por día")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    Divider()
                    
                    VStack(spacing: 12) {
                        SummaryRow(
                            title: "IMC",
                            value: String(format: "%.1f", formData.calculatedIMC ?? 0),
                            color: .black
                        )
                        SummaryRow(
                            title: "Categoría",
                            value: formData.imcCategory,
                            color: mainYellow
                        )
                        SummaryRow(
                            title: "Objetivo",
                            value: formData.goal.rawValue,
                            color: .blue
                        )
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
            }
        }
    }
}

#Preview {
    SignupView()
}
