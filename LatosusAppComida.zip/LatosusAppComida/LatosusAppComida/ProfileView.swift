import SwiftUI

struct ProfileView: View {
    @State private var userData: UserData?
    @State private var showError = false
    @Environment(\.dismiss) var dismiss
    
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    func loadData() {
        do {
            userData = try UserDataManager.shared.loadUserData()
        } catch {
            showError = true
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                mainYellow.opacity(0.1).ignoresSafeArea()
                
                if let userData = userData {
                    VStack(spacing: 20) {
                        Text("Información del Perfil")
                            .font(.system(size: 35, weight: .bold))
                            .padding(.top, 30)
                        
                        VStack(alignment: .leading, spacing: 15) {
                            InfoRow(title: "Nombre", value: userData.name)
                            InfoRow(title: "Edad", value: "\(userData.age) años")
                            InfoRow(title: "Peso", value: "\(userData.weight) kg")
                            InfoRow(title: "Altura", value: "\(userData.height) cm")
                            InfoRow(title: "Género", value: userData.gender)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white)
                                .shadow(radius: 5)
                        )
                        .padding()
                        
                        Spacer()
                    }
                }
            }
            .navigationBarItems(leading: Button("Volver") {
                dismiss()
            })
        }
        .onAppear(perform: loadData)
        .alert("Error al cargar datos", isPresented: $showError) {
            Button("OK", role: .cancel) { }
        }
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
                .fontWeight(.medium)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .fontWeight(.semibold)
        }
    }
}

#Preview {
    ProfileView()
}
