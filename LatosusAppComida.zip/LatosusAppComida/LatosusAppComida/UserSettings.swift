//
//  UserSettings.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

// UserSettings.swift
import Foundation

class UserSettings: ObservableObject {
    @Published var name = ""
    @Published var currentCalories = 280
    @Published var dailyGoal = 2000
    @Published var meals: [Meal] = []
    
    func addMeal(name: String, calories: Int, portions: Int, description: String) {
        let meal = Meal(
            title: name,
            description: description,
            caloriesPerPortion: calories,
            portions: portions,
            totalCalories: calories * portions,
            dateAdded: Date()
        )
        meals.append(meal)
        currentCalories += meal.totalCalories
    }
}
