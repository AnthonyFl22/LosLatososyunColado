//
//  TipModels.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct Tip: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let icon: String
    let category: TipCategory
}

enum TipCategory: String, CaseIterable {
    case breakfast = "Desayuno"
    case hydration = "Hidratación"
    case snacks = "Snacks"
    case nutrition = "Nutrición"
    
    var icon: String {
        switch self {
        case .breakfast: return "sun.max.fill"
        case .hydration: return "drop.fill"
        case .snacks: return "leaf.fill"
        case .nutrition: return "heart.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .breakfast: return .orange
        case .hydration: return .blue
        case .snacks: return .green
        case .nutrition: return .red
        }
    }
}
