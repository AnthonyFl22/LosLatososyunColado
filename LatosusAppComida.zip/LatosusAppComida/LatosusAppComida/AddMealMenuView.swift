//
//  AddMealMenuView.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct MealOption: Identifiable {
    let id = UUID()
    let name: String
    let calories: Int
}

struct AddMealMenuView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var showingImagePicker: Bool
    @Binding var showingMenuSelection: Bool
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    let mealOptions = [
        MealOption(name: "Sopa de Fideos", calories: 200),
        MealOption(name: "Chilaquiles", calories: 450),
        MealOption(name: "Manzana Roja", calories: 80),
        MealOption(name: "Enchiladas", calories: 420),
        MealOption(name: "Quesadilla", calories: 120)
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            RoundedRectangle(cornerRadius: 3)
                .fill(Color.gray.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, 10)
            
            Text("MENU")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.bottom, 10)
            
            // Tomar fotografía button
            Button(action: {
                showingImagePicker = true
                dismiss()
            }) {
                HStack {
                    Image(systemName: "camera.fill")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                        
                    Spacer()
                    Text("Tomar fotografía")
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.yellow)
                )
            }
            .padding(.horizontal)
            
            // Menu Items
            ScrollView {
                VStack(spacing: 12) {
                    ForEach(mealOptions) { meal in
                        Button(action: {
                            // Handle meal selection
                            print("Selected \(meal.name)")
                            showingMenuSelection = true
                            dismiss()
                        }) {
                            HStack {
                                Text(meal.name)
                                    .fontWeight(.medium)
                                Spacer()
                                Text("\(meal.calories) cal")
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )
                        }
                        .foregroundColor(.black)
                    }
                }
                .padding(.horizontal)
            }
            
            Spacer()
        }
        .background(Color.white)
        .cornerRadius(15)
    }
}
