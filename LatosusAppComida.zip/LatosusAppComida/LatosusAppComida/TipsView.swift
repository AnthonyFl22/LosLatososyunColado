import SwiftUI

struct TipsView: View {
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    let tips = TipData.tips
    
    var categorizedTips: [TipCategory: [Tip]] {
        Dictionary(grouping: tips, by: { $0.category })
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    // Featured Tip
                    FeaturedTipCard()
                        .padding(.horizontal)
                    
                    // Categories
                    ForEach(TipCategory.allCases, id: \.self) { category in
                        if let categoryTips = categorizedTips[category] {
                            CategorySection(category: category, tips: categoryTips)
                        }
                    }
                }
                .padding(.vertical)
            }
            .background(mainYellow.opacity(0.1))
            .navigationTitle("Tips")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    TipsView()
}
