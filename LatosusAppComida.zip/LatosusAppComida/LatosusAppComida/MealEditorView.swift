import SwiftUI

struct MealEditorView: View {
    let image: UIImage? // Optional because menu selection won't have image
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var userSettings: UserSettings
    
    // Hardcoded data
    let detectedFood = "Chilaquiles Verdes"
    let detectedCalories = 450 // per portion
    let detectedDescription = "Tortillas fritas en salsa verde, pollo desmenuzado, crema, queso y cebolla"
    
    @State private var portions = 1
    @State private var showingConfirmation = false
    
    var totalCalories: Int {
        detectedCalories * portions
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    if let image = image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .cornerRadius(15)
                    }
                    
                    // Food Info Card
                    VStack(spacing: 15) {
                        Text(detectedFood)
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text(detectedDescription)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Divider()
                        
                        // Portions Counter
                        HStack {
                            Text("Porciones")
                                .foregroundColor(.gray)
                            Spacer()
                            Button(action: { if portions > 1 { portions -= 1 } }) {
                                Image(systemName: "minus.circle.fill")
                                    .foregroundColor(.gray)
                                    .font(.title2)
                            }
                            Text("\(portions)")
                                .font(.title2)
                                .fontWeight(.bold)
                                .frame(width: 40)
                            Button(action: { portions += 1 }) {
                                Image(systemName: "plus.circle.fill")
                                    .foregroundColor(.green)
                                    .font(.title2)
                            }
                        }
                        
                        Divider()
                        
                        // Calories Display
                        VStack {
                            Text("\(totalCalories)")
                                .font(.system(size: 40, weight: .bold))
                            Text("calorías totales")
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(color: Color.black.opacity(0.1), radius: 5)
                    .padding(.horizontal)
                    
                    // Action Buttons
                    HStack(spacing: 15) {
                        Button(action: { dismiss() }) {
                            Text("Cancelar")
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.red)
                                .cornerRadius(10)
                        }
                        
                        Button(action: {
                            userSettings.addMeal(
                                name: detectedFood,
                                calories: detectedCalories,
                                portions: portions,
                                description: detectedDescription
                            )
                            showingConfirmation = true
                        }) {
                            Text("Registrar")
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .navigationTitle("Detalles de comida")
            .navigationBarTitleDisplayMode(.inline)
        }
        .alert("Comida registrada", isPresented: $showingConfirmation) {
            Button("OK", role: .cancel) {
                dismiss()
            }
        } message: {
            Text("Se han agregado \(totalCalories) calorías a tu contador diario")
        }
    }
}

#Preview {
    MealEditorView(image: nil)
        .environmentObject(UserSettings())
}
