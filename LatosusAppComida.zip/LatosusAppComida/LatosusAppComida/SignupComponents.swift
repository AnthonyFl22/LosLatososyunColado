//
//  SignupComponents.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct CustomTextField: View {
    @Binding var text: String
    let placeholder: String
    let imageName: String
    
    var body: some View {
        HStack {
            Image(systemName: imageName)
                .foregroundColor(.gray)
                .frame(width: 44)
            
            TextField(placeholder, text: $text)
                .autocapitalization(.none)
            
            Spacer()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.white)
                .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 5)
        )
    }
}

struct StepIndicator: View {
    let currentStep: Int
    let totalSteps: Int
    let mainYellow: Color
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(1...totalSteps, id: \.self) { step in
                Circle()
                    .fill(step <= currentStep ? mainYellow : Color.gray.opacity(0.3))
                    .frame(width: 8, height: 8)
            }
        }
        .padding()
    }
}

struct GoalCard: View {
    let goal: Goal
    let isSelected: Bool
    let mainYellow: Color
    
    var body: some View {
        VStack(spacing: 15) {
            Image(systemName: goal.icon)
                .font(.system(size: 30))
                .foregroundColor(isSelected ? mainYellow : .gray)
            
            Text(goal.rawValue)
                .font(.headline)
                .foregroundColor(isSelected ? .black : .gray)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 15)
                .stroke(isSelected ? mainYellow : Color.gray.opacity(0.3), lineWidth: 2)
        )
    }
}

struct SummaryRow: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .fontWeight(.medium)
                .foregroundColor(color)
        }
        .padding(.vertical, 8)
    }
}

struct NavigationButtons: View {
    let canProceed: Bool
    let currentStep: Int
    let onBack: () -> Void
    let onNext: () -> Void
    let mainYellow: Color
    
    var body: some View {
        HStack(spacing: 20) {
            if currentStep > 1 {
                Button(action: onBack) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Atrás")
                    }
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(color: .black.opacity(0.1), radius: 5)
                }
            }
            
            Button(action: onNext) {
                HStack {
                    Text(currentStep == 3 ? "Comenzar" : "Siguiente")
                    if currentStep != 3 {
                        Image(systemName: "chevron.right")
                    }
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(canProceed ? mainYellow : Color.gray)
                .cornerRadius(10)
                .shadow(color: canProceed ? mainYellow.opacity(0.3) : Color.gray.opacity(0.3), radius: 5)
            }
            .disabled(!canProceed)
        }
        .padding(.horizontal)
    }
}
