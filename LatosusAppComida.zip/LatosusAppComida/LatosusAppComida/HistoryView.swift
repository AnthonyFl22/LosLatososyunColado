//
//  HistoryView.swift
//  LatosusAppComida
//
//  Created by CEDAM05 on 26/11/24.
//

import SwiftUI

struct HistoryView: View {
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    
    // Hardcoded meals
    let meals = [
        Meal(
            title: "Chilaquiles Verdes",
            description: "Tortillas fritas en salsa verde con pollo y crema",
            caloriesPerPortion: 450,
            portions: 1,
            totalCalories: 450,
            dateAdded: Date()
        ),
        Meal(
            title: "Sopa de Fideos",
            description: "Sopa de fideos en caldo de jitomate, servida con un toque de queso",
            caloriesPerPortion: 200,
            portions: 1,
            totalCalories: 200,
            dateAdded: Date().addingTimeInterval(-3600) // 1 hour ago
        ),
        Meal(
            title: "Manzana Roja",
            description: "Manzana fresca y crujiente, ideal como snack saludable.",
            caloriesPerPortion: 80,
            portions: 1,
            totalCalories: 80,
            dateAdded: Date().addingTimeInterval(-7200) // 2 hours ago
        )
    ]
    
    var totalCaloriesForDay: Int {
        meals.reduce(0) { $0 + $1.totalCalories }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                mainYellow.opacity(0.1).ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Total calories card
                    VStack(spacing: 5) {
                        Text("Calorías totales del día")
                            .font(.headline)
                            .foregroundColor(.gray)
                        Text("730")
                            .font(.system(size: 40, weight: .bold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(color: Color.black.opacity(0.1), radius: 5)
                    .padding(.horizontal)
                    
                    ScrollView {
                        LazyVStack(spacing: 15) {
                            ForEach(meals) { meal in
                                MealCard(meal: meal)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Historial")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct MealCard: View {
    let meal: Meal
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(meal.title)
                    .font(.headline)
                Spacer()
                Text("\(meal.totalCalories) cal")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Text(meal.description)
                .font(.subheadline)
                .foregroundColor(.gray)
            
            HStack {
                Text("Porciones: \(meal.portions)")
                    .font(.caption)
                    .foregroundColor(.gray)
                
                Spacer()
                
                Text("\(meal.caloriesPerPortion) cal/porción")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}
