import Foundation

struct MealAlt: Codable, Identifiable {
    let id: UUID
    let title: String
    let description: String
    let caloriesPerPortion: Int
    let portions: Int
    let totalCalories: Int
    let dateAdded: Date
    
    init(title: String, description: String, caloriesPerPortion: Int, portions: Int) {
        self.id = UUID()
        self.title = title
        self.description = description
        self.caloriesPerPortion = caloriesPerPortion
        self.portions = portions
        self.totalCalories = caloriesPerPortion * portions
        self.dateAdded = Date()
    }
}

struct UserData: Codable {
    let name: String
    let age: Int
    let weight: Double
    let height: Double
    let gender: String
    var meals: [MealAlt]
    
    init(name: String, age: Int, weight: Double, height: Double, gender: String, meals: [MealAlt] = []) {
        self.name = name
        self.age = age
        self.weight = weight
        self.height = height
        self.gender = gender
        self.meals = meals
    }
}

class UserDataManager {
    static let shared = UserDataManager()
    
    private let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private let fileName = "userData.json"
    
    private init() {}
    
    func saveUserData(_ userData: UserData) throws {
        let fileURL = documentsPath.appendingPathComponent(fileName)
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(userData)
        try data.write(to: fileURL)
        print(fileURL)
    }
    
    func loadUserData() throws -> UserData {
        let fileURL = documentsPath.appendingPathComponent(fileName)
        let data = try Data(contentsOf: fileURL)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(UserData.self, from: data)
    }
    
    func addMeal(_ meal: MealAlt) throws {
        var userData = try loadUserData()
        userData.meals.append(meal)
        try saveUserData(userData)
    }
    
    func getMealsForToday() throws -> [MealAlt] {
        let userData = try loadUserData()
        let calendar = Calendar.current
        return userData.meals.filter { meal in
            calendar.isDateInToday(meal.dateAdded)
        }
    }
}
