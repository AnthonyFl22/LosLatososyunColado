import SwiftUI

struct Recommendation: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let icon: String
}

struct MainView: View {
    @State private var showingImagePicker = false
    @State private var showingMealEditor = false
    @State private var selectedImage: UIImage?
    @State private var selectedTab: Tab = .home
    
    @State private var showingAddMealMenu = false
    @State private var showingMenuSelection = false
    
    @State private var showingMealDetail = false
    
    @EnvironmentObject var userSettings: UserSettings
    
    let mainYellow = Color(red: 255/255, green: 204/255, blue: 0/255)
    let emojis = ["😞", "😁", "🤩"]
    let colores = [Color.red, Color.yellow, Color.green, Color.red, Color.yellow]
    
    // Dummy data for recommendations
    let recommendations = [
        Recommendation(title: "Desayuno Balanceado", description: "Incluye proteínas y frutas en tu desayuno", icon: "sun.max.fill"),
        Recommendation(title: "Hidratación", description: "Recuerda beber 8 vasos de agua al día", icon: "drop.fill"),
        Recommendation(title: "Snack Saludable", description: "Prueba con frutos secos o una manzana", icon: "leaf.fill")
    ]
    
    // Calories tracking
    @State private var currentCalories = 1200
    let dailyCaloriesGoal = 2000
    
    var caloriePercentage: Double {
        Double(userSettings.currentCalories) / Double(userSettings.dailyGoal)
    }
    
    var statusEmoji: String {
        switch caloriePercentage {
        case ..<0.5:        // Less than 50%
            return "😋"     // Hungry
        case 0.5..<0.8:    // 50-80%
            return "😊"     // Good
        case 0.8..<1.0:    // 80-100%
            return "😌"     // Satisfied
        case 1.0..<1.2:    // 100-120%
            return "😬"     // Warning
        default:           // Over 120%
            return "😰"     // Overeating
        }
    }
    
    var statusEmojiColor: Color {
        switch caloriePercentage {
       case ..<0.5:
           return colores[0]  // Red - Hungry
       case 0.5..<0.8:
           return colores[1]  // Yellow - Good
       case 0.8..<1.0:
           return colores[2]  // Green - Perfect
       case 1.0..<1.2:
           return colores[1]  // Yellow - Warning
       default:
           return colores[0]  // Red - Overeating
       }
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                ZStack {
                    // Content based on selected tab
                    switch selectedTab {
                    case .stats:
                        StatisticsView()
                    case .recommendations:
                        TipsView()
                    case .home:
                        mainContent
                    case .history:
                        HistoryView()
                    case .homeAlt:
                        mainContent
                    }
                }
                .ignoresSafeArea(.keyboard)
                .frame(height: geometry.size.height - 49)
                
                CustomTabBar(
                    selectedTab: $selectedTab,
                    showingAddMealMenu: $showingAddMealMenu
                )
            }
            .ignoresSafeArea(.keyboard)
            .sheet(isPresented: $showingAddMealMenu) {
                AddMealMenuView(
                    showingImagePicker: $showingImagePicker,
                    showingMenuSelection: $showingMenuSelection
                )
                .presentationDetents([.height(450)])
                .presentationDragIndicator(.visible)
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImage: $selectedImage, sourceType: .camera)
            }
            .onChange(of: selectedImage) { _ in
                if selectedImage != nil {
                    showingMealDetail = true
                }
            }
            .sheet(isPresented: $showingMealDetail) {
                MealEditorView(image: selectedImage)
                    .environmentObject(userSettings)
            }
            .sheet(isPresented: $showingMenuSelection) {
                MealEditorView(image: nil)
                    .environmentObject(userSettings)
            }
            .environmentObject(userSettings)
        }
        }
        
    
    var mainContent: some View {
        NavigationView {
            ZStack {
                mainYellow.opacity(0.1).ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Welcome and Calories Section
                        VStack(spacing: 15) {
                            Text("¡Hola \(userSettings.name)!")
                                .font(.title)
                                .fontWeight(.bold)
                            
                            // Calories Card
                            VStack(spacing: 10) {
                                Text("Calorías del día")
                                    .font(.headline)
                                    .foregroundColor(.gray)
                                
                                Text("\(userSettings.currentCalories)")
                                    .font(.system(size: 40, weight: .bold))
                                + Text(" / \(userSettings.dailyGoal)")
                                    .font(.title2)
                                    .foregroundColor(.gray)
                                
                                // Progress Bar
                                GeometryReader { geometry in
                                    ZStack(alignment: .leading) {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.gray.opacity(0.2))
                                            .frame(height: 10)
                                        
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(mainYellow)
                                            .frame(width: min(CGFloat(userSettings.currentCalories) / CGFloat(userSettings.dailyGoal) * geometry.size.width, geometry.size.width), height: 10)
                                    }
                                }
                                .frame(height: 10)
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(15)
                            .shadow(color: Color.black.opacity(0.1), radius: 5)
                        }
                        .padding(.horizontal)
                        
                        // Emoji Status
                        Text(statusEmoji)
                            .font(.system(size: 120))
                            .shadow(color: statusEmojiColor, radius: 40.0)
                            .padding(.vertical, 20)
                        
                        // Recommendations Section
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Recomendaciones del día")
                                .font(.title2)
                                .fontWeight(.bold)
                                .padding(.horizontal)
                            
                            ForEach(recommendations) { recommendation in
                                RecommendationCard(recommendation: recommendation)
                            }
                        }
                        
                        // Add Meal Button
                    }
                }
                    .padding(.vertical)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
}

struct RecommendationCard: View {
    let recommendation: Recommendation
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: recommendation.icon)
                .font(.title)
                .foregroundColor(.yellow)
                .frame(width: 50)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(recommendation.title)
                    .font(.headline)
                
                Text(recommendation.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.05), radius: 5)
        .padding(.horizontal)
    }
}

#Preview {
    MainView()
        .environmentObject(UserSettings())
}
