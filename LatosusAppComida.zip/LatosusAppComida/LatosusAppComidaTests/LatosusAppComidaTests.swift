//
//  LatosusAppComidaTests.swift
//  LatosusAppComidaTests
//
//  Created by CEDAM05 on 26/11/24.
//

import Testing
@testable import LatosusAppComida

struct LatosusAppComidaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
